# EpamPEPTask8
Program to done operation of removing 'A' if it is at 0 or 1 position in given string
